package com.crud.model;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class AddPatient {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String fname;
	private String mname;
	private String lname;
	private String age;
	private String cnumber;
	private String gender;
	private String bresult;
	
	
	public AddPatient() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AddPatient(int id, String fname, String mname, String lname, String age, String cnumber, String gender,
			String bresult) {
		super();
		this.id = id;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.age = age;
		this.cnumber = cnumber;
		this.gender = gender;
		this.bresult = bresult;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getMname() {
		return mname;
	}


	public void setMname(String mname) {
		this.mname = mname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getAge() {
		return age;
	}


	public void setAge(String age) {
		this.age = age;
	}


	public String getCnumber() {
		return cnumber;
	}


	public void setCnumber(String cnumber) {
		this.cnumber = cnumber;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getBresult() {
		return bresult;
	}


	public void setBresult(String bresult) {
		this.bresult = bresult;
	}
	
	
	
	
	
	
	

}
