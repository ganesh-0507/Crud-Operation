package com.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.crud.model.AddPatient;
import com.crud.repo.PatientRepo;
import com.crud.service.PatientService;
import org.springframework.ui.Model;

@Controller
public class HomeController {

	@Autowired
	private PatientRepo patientRepo;

	@Autowired
	private PatientService patientService;

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/addPatient")
	public String addPatient() {
		return "addPatient";
	}

	@PostMapping("/addPatient")
	public String addPatient1(@ModelAttribute AddPatient p) {
		patientRepo.save(p);
		return "redirect:/availablePatient";
	}

	@GetMapping("/availablePatient")
	public String getAllItems(Model model) {
		model.addAttribute("patients", patientService.getAllPatient());
//		return "redirect:/";
		return "availablePatient";
	}

	@GetMapping("/delete/{id}")
	public String deletePatient(@PathVariable int id) {
		patientService.deletePatient(id);
		return "redirect:/availablePatient";
	}

	@GetMapping("/edit/{id}")
	public String editPatientForm(@PathVariable int id, Model model) {
		AddPatient patient = patientService.getPatientById(id);
		model.addAttribute("patient", patient);
		return "editPatientForm";
	}
	
	  @PostMapping("/update")
	    public String updatePatient(AddPatient patient) {
	        patientService.updatePatient(patient);
	        return "redirect:/availablePatient"; 
	    }

}
