package com.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.model.AddPatient;
import com.crud.repo.PatientRepo;

@Service
public class PatientService {

	@Autowired
	private PatientRepo patientRepo;

	public List<AddPatient> getAllPatient() {
		return patientRepo.findAll();
	}

	public void deletePatient(int id) {
		patientRepo.deleteById(id);
	}
	
	
	public AddPatient getPatientById(int id) {
        Optional<AddPatient> patientOptional = patientRepo.findById(id);
        return patientOptional.orElse(null); 
    }
	
	public void updatePatient(AddPatient patient) {
		patientRepo.save(patient);
    }

}
